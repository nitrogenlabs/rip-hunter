import type { IncomingHttpHeaders, OutgoingHttpHeaders } from 'node:http2';
import type { ConnectionOptions } from 'node:tls';
export type Http2RequestOptions = {
    readonly body?: string;
    readonly headers?: OutgoingHttpHeaders;
    readonly maxResponseBytes?: number;
    readonly method?: string;
    readonly timeout?: number;
};
export type Http2Response = {
    readonly body: string;
    readonly headers: IncomingHttpHeaders;
    readonly status: number;
};
/** Node-only HTTP/2 transport. TLS verification stays enabled; HTTP statuses are returned to the caller. */
export declare const createHttp2Client: ({ origin, tls }: {
    origin: string;
    tls?: ConnectionOptions;
}) => {
    close: () => void;
    request: (path: string, options?: Http2RequestOptions) => Promise<Http2Response>;
};
