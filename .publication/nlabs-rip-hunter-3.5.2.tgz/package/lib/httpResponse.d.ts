export type HttpStatusOptions = {
    /** Bound actual error response bytes; omitted preserves legacy body handling. */
    readonly maxResponseBytes?: number;
    readonly throwHttpErrors?: boolean;
};
export declare const JSON_CONTENT_TYPE_REGEX: RegExp;
export declare const assertHttpSuccess: (response: Response, options: HttpStatusOptions) => Promise<void>;
