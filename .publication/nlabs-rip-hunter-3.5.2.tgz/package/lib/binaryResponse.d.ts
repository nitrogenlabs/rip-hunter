export declare class BinaryResponseError extends Error {
    readonly kind = "limit";
    constructor();
}
/** Preserve bytes and bound actual streamed output, regardless of response headers. */
export declare const readBinaryResponse: (response: Response, maxBytes: number) => Promise<Uint8Array>;
