/**
 * Copyright (c) 2017-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
export declare class ApiError extends Error {
    readonly responseBody?: unknown;
    readonly status?: number | undefined;
    source: Error;
    errors: string[];
    constructor(list: Array<{
        message: string;
    }>, error: Error, response?: {
        responseBody?: unknown;
        status: number;
    });
}
