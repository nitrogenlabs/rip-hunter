/** Platform fetch shape; native or test implementations may be injected. */
export type RequestImplementation = typeof fetch;
type RequestBody = {
    readonly body?: Exclude<RequestInit['body'], undefined>;
    readonly json?: never;
} | {
    readonly body?: never;
    readonly json: unknown;
};
export type HttpRequestOptions = Omit<RequestInit, 'body' | 'headers' | 'signal'> & RequestBody & {
    readonly headers?: Exclude<RequestInit['headers'], undefined>;
    readonly requestImplementation?: RequestImplementation;
    readonly signal?: AbortSignal;
    /** Milliseconds across request and consumer; zero/omitted disables the deadline. */
    readonly timeout?: number;
};
export declare class HttpRequestError extends Error {
    readonly kind: 'abort' | 'timeout';
    constructor(kind: 'abort' | 'timeout', cause?: unknown);
}
export interface HttpRequestOperation<T> {
    readonly cancel: (reason?: unknown) => void;
    readonly result: Promise<T>;
    /** Joins original request, returned consumer promise and owned late-body cleanup; not remote outcome. */
    readonly settled: Promise<void>;
}
/** Bounded publication and original settlement are deliberately independent. */
export declare const startHttpRequest: <T>(url: string, options: HttpRequestOptions, consumeResponse: (response: Response) => T | Promise<T>) => HttpRequestOperation<T>;
/** Domain status, redirect validation and decoding execute inside the shared operation. */
export declare const httpRequest: <T>(url: string, options: HttpRequestOptions, consumeResponse: (response: Response) => T | Promise<T>) => Promise<T>;
export { BinaryResponseError, readBinaryResponse } from './binaryResponse.js';
export { assertHttpSuccess, type HttpStatusOptions } from './httpResponse.js';
