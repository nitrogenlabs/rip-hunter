/**
 * Copyright (c) 2017-Present, Nitrogen Labs, Inc.
 * Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.
 */
/** Request bodies sent as they are, never JSON-encoded: multipart forms, files, bytes, form-encoded fields and streams. */
export type HunterNativeBody = FormData | Blob | ArrayBuffer | ArrayBufferView | URLSearchParams | ReadableStream;
/** How a successful response is read. Omitted: JSON when the server says so, otherwise text. */
export type HunterResponseType = 'arrayBuffer' | 'blob' | 'json' | 'text';
export interface HunterOptionsType {
    /** Explicit Fetch credential mode; omitted preserves the platform default. */
    readonly credentials?: RequestCredentials;
    readonly headers?: Headers;
    readonly token?: string;
    readonly variables?: any;
    readonly timeout?: number;
    readonly cache?: boolean;
    /** Reject non-2xx HTTP responses. Set false only for legacy response handling. */
    readonly throwHttpErrors?: boolean;
    /** Read the response as binary (`blob`, `arrayBuffer`), `text` or `json`, whatever its content type says. */
    readonly responseType?: HunterResponseType;
}
export interface HunterQueryType {
    readonly query: string;
    readonly variables?: any;
}
export interface HunterSSEOptionsType {
    readonly headers?: Headers;
    readonly token?: string;
    readonly timeout?: number;
    readonly retryInterval?: number;
    readonly maxRetries?: number;
}
export interface HunterSSEEventType {
    readonly data: string;
    readonly type: string;
    readonly id?: string;
    readonly retry?: number | undefined;
}
export interface HunterSSECallbackType {
    onMessage?: (event: HunterSSEEventType) => void;
    onOpen?: (event: Event) => void;
    onError?: (error: Error | Event) => void;
    onRetry?: (attempt: number, delay: number) => void;
}
export interface HunterSubscriptionOptionsType {
    readonly headers?: Headers;
    readonly token?: string;
    readonly variables?: Record<string, unknown>;
    readonly connectionParams?: Record<string, unknown>;
    readonly reconnectInterval?: number;
    readonly maxReconnectAttempts?: number;
    readonly timeout?: number;
}
export interface HunterSubscriptionCallbackType {
    onNext?: (data: any) => void;
    onError?: (error: Error | Event) => void;
    onComplete?: () => void;
    onReconnect?: (attempt: number) => void;
}
export declare const removeSpaces: (str: string) => string;
export declare const queryString: (json: any) => string;
/** True for bodies fetch must receive untouched (FormData sets its own multipart boundary). */
export declare const isNativeBody: (value: unknown) => value is HunterNativeBody;
export declare const ajax: (url: string, method: string, params?: any, options?: HunterOptionsType) => Promise<any>;
export declare const get: (url: string, params?: any, options?: HunterOptionsType) => Promise<any>;
export declare const post: (url: string, params?: any, options?: HunterOptionsType) => Promise<any>;
export declare const put: (url: string, params?: any, options?: HunterOptionsType) => Promise<any>;
export declare const del: (url: string, params?: any, options?: HunterOptionsType) => Promise<any>;
export declare const toGql: (obj: any) => string;
export declare const graphqlQuery: (url: string, query: HunterQueryType | HunterQueryType[], options?: HunterOptionsType) => Promise<any>;
export declare const query: (url: string, body: string, options?: HunterOptionsType) => Promise<any>;
export declare const mutation: (url: string, body: string, options?: HunterOptionsType) => Promise<any>;
export declare const subscribe: (url: string, query: string, callbacks: HunterSubscriptionCallbackType, options?: HunterSubscriptionOptionsType) => (() => void);
export declare const subscribeSSE: (url: string, callbacks: HunterSSECallbackType, options?: HunterSSEOptionsType) => (() => void);
export { ApiError } from './errors/ApiError.js';
export { GraphQLRequestError, graphqlRequest } from './graphql.js';
export type { GraphQLProviderError, GraphQLRequestErrorKind, GraphQLRequestOperation, GraphQLRequestOptions } from './graphql.js';
