/** Schedule a finite positive absolute deadline without platform timer overflow. */
export declare const scheduleDeadline: (timeout: number, expire: () => void) => (() => void);
