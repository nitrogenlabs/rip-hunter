export interface GraphQLRequestOperation {
    readonly operationName?: string;
    readonly query: string;
    readonly variables?: Record<string, unknown>;
}
export interface GraphQLRequestOptions {
    readonly headers?: Exclude<RequestInit['headers'], undefined>;
    /** Read HTTP error bodies by default; false classifies status immediately. */
    readonly readHttpErrorBody?: boolean;
    readonly requestImplementation?: typeof fetch;
    readonly signal?: AbortSignal;
    /** Disabled by default. A positive timeout cancels the underlying request. */
    readonly timeout?: number;
    readonly token?: string;
}
export interface GraphQLProviderError {
    readonly [key: string]: unknown;
    readonly message?: string;
}
export type GraphQLRequestErrorKind = 'abort' | 'graphql' | 'http' | 'invalid_response' | 'missing_data' | 'network' | 'timeout';
interface ErrorDetails {
    readonly cause?: unknown;
    readonly errors?: readonly GraphQLProviderError[];
    readonly responseBody?: unknown;
    readonly status?: number;
}
export declare class GraphQLRequestError extends Error {
    readonly errors: readonly GraphQLProviderError[];
    readonly kind: GraphQLRequestErrorKind;
    readonly responseBody: unknown;
    readonly status: number | undefined;
    constructor(kind: GraphQLRequestErrorKind, message: string, details?: ErrorDetails);
}
/** Strict JSON GraphQL transport, independent of sessions, stores and subscriptions. */
export declare const graphqlRequest: <T>(endpoint: string, operation: GraphQLRequestOperation, options?: GraphQLRequestOptions) => Promise<T>;
export {};
