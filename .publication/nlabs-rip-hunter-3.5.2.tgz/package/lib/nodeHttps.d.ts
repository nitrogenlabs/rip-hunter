import { request } from 'node:https';
import type { IncomingMessage, OutgoingHttpHeaders } from 'node:http';
export declare class HttpsBytesError extends Error {
    readonly kind: 'connect-timeout' | 'interrupted' | 'limit' | 'timeout';
    constructor(kind: HttpsBytesError['kind'], message: string);
}
export interface HttpsBytesOptions {
    /** Absolute DNS/TCP/TLS establishment phase in milliseconds; zero/omitted disables it. */
    readonly connectTimeout?: number;
    readonly headers?: OutgoingHttpHeaders;
    /** Node socket inactivity, not an absolute request deadline. */
    readonly idleTimeout?: number;
    /** Domain status policy runs before bytes are consumed. */
    readonly inspectResponse?: (response: IncomingMessage) => void;
    readonly maxBytes: number;
    readonly method?: string;
    readonly payload: Uint8Array;
    readonly requestImplementation?: typeof request;
    /** Caller cancellation, including an independently owned absolute request/body deadline. */
    readonly signal?: AbortSignal;
}
/** Node-only byte transport. Never redirects or retries a request. */
export declare const httpsBytesRequest: (url: string, options: HttpsBytesOptions) => Promise<Buffer>;
